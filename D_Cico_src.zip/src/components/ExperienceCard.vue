<template>
  <div class="experience-card">
    <h2>{{ experience.name }}</h2>
    <p>{{ experience.description }}</p>
    <img :src="'/images/' + experience.image" :alt="experience.name" />
  </div>
</template>

<script>
export default {
  props: {
    experience: Object, 
  },
};
</script>

