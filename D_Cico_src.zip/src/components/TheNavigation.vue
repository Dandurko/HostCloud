<template>
   
  <header>
    <nav id="nav">
      <RouterLink to="/">Home</RouterLink>
      <RouterLink v-for="destination in destinations" :to="`/destination/${destination.slug}`"
        >{{ destination.slug }}</RouterLink
      >
    </nav>
  </header>

  <div class="container"><RouterView /></div>
</template>
<script>
import { RouterLink, RouterView } from "vue-router";
import dataDestinations from "../data.json";
export default {
  data() {
    return {
      destinations: dataDestinations.destinations,
    };
  },
};
</script>
