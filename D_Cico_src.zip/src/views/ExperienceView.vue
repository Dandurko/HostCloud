<template>
  <div class="experience-view">
    <ExperienceCard :experience="experience" />
  </div>
</template>

<script>
import ExperienceCard from '../components/ExperienceCard.vue';
import dataDestinations from '../data.json';

export default {
  components: {
    ExperienceCard,
  },
  data() {
    return {
      experience: {}, // Inicializujte objekt pre skúsenosť
    };
  },
  created() {
    this.loadExperience();
  },
  watch: {
  '$route': 'loadExperience',
},
  methods: {
    loadExperience() {
      const currentSlug = this.$route.params.slug;
      const currentExperienceSlug = this.$route.params.experienceSlug;

      const destination = dataDestinations.destinations.find((dest) => dest.slug === currentSlug);

      if (destination) {
        this.experience = destination.experiences.find((experience) => experience.slug === currentExperienceSlug);
      }
    },
  },
};
</script>
