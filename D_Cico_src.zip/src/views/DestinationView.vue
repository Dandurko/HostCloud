<template>
 <div class="destination-view">
    <h1>Destination Details</h1>
    <div v-for="destination in filteredDestinations" :key="destination.slug">
      <h2>{{ destination.name }}</h2>
      <p>{{ destination.description }}</p>
      <img :src="'/images/' + destination.image" :alt="destination.name" />

      <h3>Experiences:</h3>
      <router-link
        v-for="experience in destination.experiences"
        :key="experience.slug"
        :to="`/destination/${destination.slug}/${experience.slug}`"
      >
      <img :src="'/images/' + experience.image" :alt="experience.name" />
      {{experience.name}}
      </router-link>
    </div>

    <router-view></router-view>
  </div>
</template>

<script>
import dataDestinations from "../data.json";

export default {
  data() {
    return {
      destinations: dataDestinations.destinations,
    };
  },
  computed: {
    filteredDestinations() {
      const currentSlug = this.$route.params.slug;
      return this.destinations.filter((destination) => destination.slug === currentSlug);
    },
  },
};
</script>