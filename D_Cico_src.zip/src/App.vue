<template>
  
  <TheNavigation/>
</template>
<script>
import TheNavigation from "@/components/TheNavigation.vue";

export default {
  components: {
    TheNavigation, 
  },
};
</script>
